import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import EchartsPage from './components/EchartPage';
import Login from './components/Login';
import Page1 from "./components/Page1";
import Page0 from "./components/Page0";
import Page2 from './components/Page2'
import Layout from "./Layout";
import "./App.css"
import Page3 from "./components/Page3";
import Page4 from "./components/Page4";
function App() {
  return (
      <div className="App">
          <Router>
              <Routes>
                  <Route path="/" element={<Login />} />
              </Routes>
              <Layout/>
              <Routes>
                  <Route path="/page0"  element={<Page0/>} />
                  <Route path="/page1"  element={<Page1/> } />
                  <Route path="/page2"  element={<Page2/>} />
                  <Route path="/page3"  element={<Page3 />} />
                  <Route path="/page4"  element={<Page4 />} />
              </Routes>
          </Router>
      </div>

);
}

export default App;