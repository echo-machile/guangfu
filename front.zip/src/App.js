import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import EchartsPage from './components/EchartPage';
import Login from './components/Login';
import Page1 from "./components/Page1";
import Page0 from "./components/Page0";
import Page2 from './components/Page2';
import Layout from "./Layout";
import "./App.css";
import Page3 from "./components/Page3";
import Page4 from "./components/Page4";

function App() {
    return (
        <div className="App">
            <Router>
                <Routes>
                    <Route path="/login" element={<Login />} />
                    <Route path="/page0" element={<Layout><Page0 /></Layout>} />
                    <Route path="/page1" element={<Layout><Page1 /></Layout>} />
                    <Route path="/page2" element={<Layout><Page2 /></Layout>} />
                    <Route path="/page3" element={<Layout><Page3 /></Layout>} />
                    <Route path="/page4" element={<Layout><Page4 /></Layout>} />
                </Routes>
            </Router>
        </div>
    );
}

export default App;
