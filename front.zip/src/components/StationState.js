
import React from 'react';
import { useParams } from 'react-router-dom';
import { ECharts } from 'echarts';
import ReactECharts from 'echarts-for-react';
import { fakeData } from '../data/fateData';

const EchartsPage = (props) => {
    const { id } = props;
    const data = fakeData[id - 1];

    const option = {
            title: {
                text: '电站状况',
                subtext: 'Fake Data',
                left: 'center'
            },
            tooltip: {
                trigger: 'item'
            },
            legend: {
                orient: 'vertical',
                left: 'left'
            },
            series: [
                {
                    name: '电站状况',
                    type: 'pie',
                    radius: '50%',
                    data: [
                        { value: 87, name: '正常' },
                        { value: 10, name: '离线' },
                        { value: 3, name: '故障' },
                    ],
                    emphasis: {
                        itemStyle: {
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowColor: 'rgba(0, 0, 0, 0.5)'
                        }
                    }
                }
            ]
        };

    return (
        <div>
            <ReactECharts option={option} style={{ height: '400px', width: '100%' }} />
        </div>
    );
};

export default EchartsPage;
