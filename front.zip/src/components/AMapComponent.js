import React, { useState, useEffect } from 'react';
import AMapLoader from '@amap/amap-jsapi-loader';

const AMapComponent = () => {
    const [layers, setLayers] = useState('normal');
    const [mapInstance, setMapInstance] = useState(null);

    const toggleMapType = () => {
        if (layers === 'normal') {
            setLayers('satellite');
        } else {
            setLayers('normal');
        }
    };

    useEffect(() => {
        if (mapInstance) {
            mapInstance.setLayers(layers === 'normal' ? [new window.AMap.TileLayer()] : [new window.AMap.TileLayer.Satellite()]);
        }
    }, [layers, mapInstance]);

    const mapKey = 'fdbb958972ec67d268114b4866ee7349';

    useEffect(() => {
        AMapLoader.load({
            key: mapKey,
            version: '2.0',
            plugins: [],
        }).then((AMap) => {
            const map = new AMap.Map('map-container', {
                center: [112.549248, 37.857014],
                zoom: 10,
                //mapStyle: 'amap://styles/dark',
            });
            setMapInstance(map);
        });
    }, [mapKey]);

    return (
        <div style={{ position: 'relative', width: '100%', height: '70%' }}>
            <div id="map-container" style={{ width: '100%', height: '100%' }}></div>
            <button
                onClick={toggleMapType}
                style={{
                    position: 'absolute',
                    top: '10px',
                    right: '10px',
                    zIndex: 100,
                    padding: '5px 10px',
                    background: 'white',
                    border: '1px solid #ccc',
                    borderRadius: '5px',
                    cursor: 'pointer',
                }}
            >
                {layers === 'normal' ? '切换至卫星地图' : '切换至普通地图'}
            </button>
        </div>
    );
};

export default AMapComponent;
