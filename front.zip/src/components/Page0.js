import React from 'react';
import { Table } from 'antd';
import ChartComponent from './ChartComponent';
import {Paper} from "@mui/material";
import {EnvironmentOutlined} from "@ant-design/icons"; // 导入您的图表组件，例如饼图、柱状图、折线图等
import StationState from "./StationState";
import MaxPercent from "./MaxPercent";
import DayElect from "./DayElect";

// 用于表格的假数据
const fakeData = [
    {
        key: '1',
        panelId: '001',
        status: '故障',
        timestamp: '2023-04-29 09:00:00',
    },{
        key: '1',
        panelId: '001',
        status: '故障',
        timestamp: '2023-04-29 09:00:00',
    },{
        key: '1',
        panelId: '001',
        status: '故障',
        timestamp: '2023-04-29 09:00:00',
    },{
        key: '1',
        panelId: '001',
        status: '故障',
        timestamp: '2023-04-29 09:00:00',
    },{
        key: '1',
        panelId: '001',
        status: '故障',
        timestamp: '2023-04-29 09:00:00',
    },
    // ...
];

const columns = [
    {
        title: '光电板序号',
        dataIndex: 'panelId',
        color:"black"
    },
    {
        title: '故障状态',
        dataIndex: 'status',
    },
    {
        title: '故障时间',
        dataIndex: 'timestamp',
    },
];

const Page0 = () => {
    return (
        <div style={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
            <div style={{ display: 'flex', flex: 1 }}>
                <div style={{ flex: 1 }}>
                    {/*<ChartComponent type="pie" />*/}
                    <StationState></StationState>
                </div>
                <div style={{ flex: 1 }}>
                    <Paper style={{height:"86%",borderRadius:"2rem",margin:"0 1rem",paddingTop:"1rem",backgroundColor:'aqua'}} >
                        <h2>
                            <EnvironmentOutlined /> 光伏电站环境实时监控
                        </h2>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <div style={{width:"33%",fontSize: "1.5rem"}}>
                                <p >正常状态 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem"}}>69536块 </p>
                            </div>
                            <div style={{width:"33%",fontSize: "1.5rem"}}>
                                <p >离线状态 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem"}}>392块 </p>
                            </div>
                            <div style={{width:"33%",fontSize: "1.5rem"}}>
                                <p>故障状态 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem"}}>72块 </p>
                            </div>
                        </div>
                        <div style={{ textAlign:"center" }}>
                            <div style={{fontSize: "1.5rem",textAlign:"center"}}>
                                <p >今日总发电量 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem"}}>23257KW·h</p>
                            </div>
                        </div>
                    </Paper>

                </div>
                <div style={{ flex: 1 }}>
                    <ChartComponent type="bar" />
                </div>
            </div>
            <div style={{ display: 'flex', flex: 1 }}>
                <div style={{ flex: 1 }}>
                    {/*<<ChartComponent type="circlePercentage" />>*/}
                    <MaxPercent></MaxPercent>
                </div>
                <div style={{ flex: 1 }}>
                    <Table  dataSource={fakeData} columns={columns} />
                </div>
                <div style={{ flex: 1 }}>
                    <DayElect></DayElect>
                </div>
            </div>
        </div>
    );
};

export default Page0;
