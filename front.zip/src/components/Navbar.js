import React from 'react';
import { NavLink } from 'react-router-dom';
import './Navbar.css';

const Navbar = () => {
    return (
        <nav className="navbar">

            <ul className="navbar-nav">
                <li className="nav-title">
                    光伏发电数据监测
                </li>
                <li className="nav-item">
                    <NavLink to="/page0" activeClassName="active" className="nav-link">
                        首页
                    </NavLink>
                </li>
                <li className="nav-item">
                    <NavLink to="/page1" activeClassName="active" className="nav-link">
                        运行监控
                    </NavLink>
                </li>
                <li className="nav-item">
                    <NavLink to="/page2" activeClassName="active" className="nav-link">
                        显示
                    </NavLink>
                </li>
                <li className="nav-item">
                    <NavLink to="/page3" activeClassName="active" className="nav-link">
                        数据分析
                    </NavLink>
                </li>
                <li className="nav-item">
                    <NavLink to="/page4" activeClassName="active" className="nav-link">
                        预测分析
                    </NavLink>
                </li>
            </ul>
        </nav>
    );
};

export default Navbar;
