import React from 'react';
import ReactECharts from 'echarts-for-react';

const ChartComponent = () => {
    const option = {
        color:"orange",
        title: {
            text: '光伏发电站日发电总量',
            textStyle:{
                color: "white",
            }
        },
        tooltip: {
            trigger: 'axis'
        },
        xAxis: {
            type: 'category',
            data:  [1,
                2,
                3,
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                12,
                13,
                14,
                15,
                16,
                17,
                18,
                19,
                20,
                21,
                22,
                23,
                24,
                25,
                26,
                27,
                28,
                29,
                30,
                31],
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                formatter: '{value}万KW/h',
            },
        },
        series: [
            {
                data: [3.4,
                    4.2,
                    2.7,
                    5.2,
                    3.9,
                    4.1,
                    3.9,
                    4,
                    4.5,
                    2,
                    3.4,
                    4.3,
                    4.9,
                    3.5,
                    3.4,
                    3.4,
                    4.3,
                    4,
                    3.2,
                    3.7,
                    2.8,
                    2.5,
                    2.7,
                    3,
                    3.6,
                    4.2,
                    3.5,
                    2.8,
                    3.4,
                    3.6,
                    3.4],
                type: 'bar',
                showBackground: true,
                backgroundStyle: {
                    color: 'rgba(180, 180, 180, 0.2)'
                }
            }
        ]
    };

    return (
        <ReactECharts option={option} style={{ width: '100%', height: '100%',backgroundColor: "rgba(1, 0.3, 0.2, 0.6)" }}  />
    );
};

export default ChartComponent;
