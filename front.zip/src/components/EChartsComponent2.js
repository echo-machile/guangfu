import React from 'react';
import ReactECharts from 'echarts-for-react';

const EChartsComponent2 = () => {
    const option = {
        color: ['green'],
        title: {
            text: '光照强度',
            textStyle:{
                color: 'white',
            }

        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: [ '光照强度'],
            textStyle: {
                color: 'white'
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            axisLabel: {
                color: 'white' // 设置横坐标标签颜色为红色
            },
            data: ['周一','周二','周三','周四','周五','周六','周日']
        },
        yAxis: {
            type: 'value',
            color: 'white',
            axisLabel: {
                color: 'white' // 设置横坐标标签颜色为红色
            },
        },
        series: [
            {
                name: '光照强度',
                type: 'line',
                smooth: true,
                data: [16,20,23,30,26,25,20]
            }
        ]
    };

    return (
        <ReactECharts option={option} style={{ width: '100%', height: '100%',backgroundColor: "rgba(1, 0.3, 0.2, 0.6)" }}  />
    );
};

export default EChartsComponent2;
