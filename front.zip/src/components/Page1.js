import React, { useState, useEffect } from 'react';
import { Grid, Paper, Typography, MenuItem, Select } from '@mui/material';
import { format } from 'date-fns';
import './page1.css'


const CurrentTime = () => {
    const [currentTime, setCurrentTime] = useState(new Date());



    useEffect(() => {
        const interval = setInterval(() => {
            setCurrentTime(new Date());
        }, 1000);
        return () => clearInterval(interval);
    }, []);



    return (
            <Typography variant="h6"  className="current-time" style={{textAlign: "center",width: "300px",backgroundColor: "dodgerblue",borderRadius:"1rem",marginBottom:"10px",paddingTop: "1rem"}} >
                {format(currentTime, 'yyyy-MM-dd HH:mm:ss')}
            </Typography>

    );
};

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const SolarPanel = ({ panelId, panelStatus, refresh }) => {
    const statusColors = {
        running: 'green',
        full: 'blue',
        stopped: 'yellow',
        forbidden: 'red',
        offline: 'gray',
    };
    const [dianya, setDianya] = useState(0);
    const [dianliu, setDianliu] = useState(0);

    useEffect(() => {
        setDianya(getRandomInt(35, 42));
        setDianliu(getRandomInt(15, 20));
    }, []);

    useEffect(() => {
        setDianya(getRandomInt(35, 42));
        setDianliu(getRandomInt(15, 20));
    }, [refresh]);

    const status = statusColors[panelStatus] || 'gray';

    return (
        <Paper sx={{ p: 2, bgcolor: 'dodgerblue', }}  elevation={16}>
            <Grid container alignItems="center" >
                <Grid item xs={2}>
                    <div style={{ width: '10px', height: '20px', backgroundColor: status }}></div>
                </Grid>
                <Grid item xs={10}>
                    <Typography variant="body2">光伏发电</Typography>
                </Grid>
            </Grid>
            <Typography variant="body1" align="center">
                G{panelId.toString().padStart(3, '0')}
            </Typography>
            <Grid container>
                <Grid item xs={3}>
                    <Typography variant="body2" align="center">
                        电压
                    </Typography>
                    <Typography variant="body2" align="center">
                        {dianya}V
                    </Typography>
                </Grid>
                <Grid item xs={3}>
                    <Typography variant="body2" align="center">
                        电流
                    </Typography>
                    <Typography variant="body2" align="center">
                        {dianliu} A
                    </Typography>
                </Grid>
                <Grid item xs={3}>
                    <Typography variant="body2" align="center">
                        功率
                    </Typography>
                    <Typography variant="body2" align="center">
                        {dianya * dianliu} W
                    </Typography>
                </Grid>
                <Grid item xs={3}>
                    <Typography variant="body2" align="center">
                        效率
                    </Typography>
                    <Typography variant="body2" align="center">
                        {getRandomInt(20,22)} %
                    </Typography>
                </Grid>
            </Grid>
        </Paper>
    );
};

const Page1 = () => {
    const [timeRange, setTimeRange] = useState('1h');


    const [age, setAge] = React.useState(1);
    const [refreshPanels, setRefreshPanels] = useState(false);
    const handleChange = (event: SelectChangeEvent) => {
        setAge(event.target.value);
        setRefreshPanels(true);
    };

    useEffect(() => {
        if (refreshPanels) {
            setRefreshPanels(false);
        }
    }, [refreshPanels]);

    const panelsData = [
        // 您可以随意更改或添加更多的数据
        { id: 1, status: getRandomInt(0,27)>0?"running":"full" },
        { id: 2, status: getRandomInt(0,27)>5?"running":"full"},
        { id: 3, status: getRandomInt(0,27)>0?"running":"forbidden" },
        { id: 4, status: getRandomInt(0,27)>0?"running":"forbidden" },
        { id: 5, status: 'offline' },
        { id: 6, status: 'running' },
        { id: 7, status: getRandomInt(0,27)>25?"full":"forbidden"},
        { id: 8, status: 'running' },
        { id: 9, status: 'running' },
        { id: 10, status: getRandomInt(0,27)>25?"forbidden":"running" },
        { id: 11, status: 'running' },
        { id: 12, status: 'running' },
        { id: 13, status: 'running' },
        { id: 14, status: getRandomInt(0,27)>5?"running":"forbidden" },
        { id: 15, status: 'running' },
        { id: 16, status: getRandomInt(0,27)>20?"forbidden":"running" },
        { id: 17, status: 'running' },
        { id: 18, status: 'running' },
        { id: 19, status: getRandomInt(0,27)>10?"forbidden":"running" },
        { id: 20, status: 'running' },
        { id: 21, status: getRandomInt(0,27)>15?"forbidden":"running" },
        { id: 22, status: 'running' },
        { id: 23, status: 'running' },
        { id: 24, status: 'running' },
        { id: 25, status: getRandomInt(0,27)>23?"stopped":"running" },
        { id: 26, status: getRandomInt(0,27)>10?"stopped":"running" },
        { id: 27, status: getRandomInt(0,27)>5?"stopped":"running" },
        { id: 28, status: getRandomInt(0,27)>0?"stopped":"forbidden" },
        // ... 更多光伏板数据
    ];

    return (
        <div align={"center"}  >
            <Grid container spacing={1} alignItems="center" justifyContent="space-between">
                <Grid item xs={11} style={{ align: "center" }}>
                    <CurrentTime />
                </Grid>
                <Grid item xs={1} style={{ textAlign: "center" }}>
              <Select
                    labelId="demo-simple-select-standard-label"
                    id="demo-simple-select-standard"
                    value={age}
                    onChange={handleChange}
                    label="Age"
                >
                    <MenuItem value={1}>001路</MenuItem>
                    <MenuItem value={2}>002路</MenuItem>
                    <MenuItem value={3}>003路</MenuItem>
                    <MenuItem value={4}>004路</MenuItem>
                    <MenuItem value={5}>005路</MenuItem>
                    <MenuItem value={6}>006路</MenuItem>
                    <MenuItem value={7}>007路</MenuItem>
                    <MenuItem value={8}>008路</MenuItem>
                    <MenuItem value={9}>009路</MenuItem>
                    <MenuItem value={10}>010路</MenuItem>
                    <MenuItem value={11}>011路</MenuItem>
                    <MenuItem value={12}>012路</MenuItem>
                    <MenuItem value={13}>013路</MenuItem>
                    <MenuItem value={14}>014路</MenuItem>
                    <MenuItem value={15}>015路</MenuItem>
                    <MenuItem value={16}>016路</MenuItem>
                    <MenuItem value={17}>017路</MenuItem>
                    <MenuItem value={18}>018路</MenuItem>
                    <MenuItem value={19}>019路</MenuItem>
                    <MenuItem value={20}>020路</MenuItem>
                    <MenuItem value={21}>021路</MenuItem>
                    <MenuItem value={22}>022路</MenuItem>
                    <MenuItem value={23}>023路</MenuItem>
                    <MenuItem value={24}>024路</MenuItem>
                    <MenuItem value={25}>025路</MenuItem>
                    <MenuItem value={26}>026路</MenuItem>
                    <MenuItem value={27}>027路</MenuItem>
                    <MenuItem value={28}>028路</MenuItem>
                </Select>
                </Grid>
            </Grid>
            <Grid container spacing={1} style={{margin: "1 1rem",backgroundColor:"dodgerblue",borderRadius:"5rem"}}>
                {panelsData.map((panel) => (
                    <Grid item key={panel.id} xs={6} sm={3} md={2} style={{paddingLeft: "1.3rem",paddingRight: "1.3rem",paddingTop:"1.8rem",paddingBottom:"1rem"}}>
                        <SolarPanel panelId={panel.id} panelStatus={panel.status} refresh={refreshPanels} />
                    </Grid>
                ))}

            </Grid>
            {/*<LinearProgress variant="determinate" value={100} sx={{ my: 4 }} />*/}
            {/*<Grid container spacing={4}>*/}
            {/*    <Grid item xs={12} md={6}>*/}
            {/*        <EChartsComponent />*/}

            {/*    </Grid>*/}
            {/*    <Grid item xs={12} md={6}>*/}
            {/*        <EChartsComponent2 />*/}
            {/*    </Grid>*/}
            {/*</Grid>*/}
        </div>
    );
};

export default Page1;

