import React from 'react';
import ReactECharts from 'echarts-for-react';

const ChartComponent = () => {
    const option = {
        tooltip: {
            trigger: 'item'
        },
        legend: {
            top: '5%',
            left: 'center',
            textStyle:{
                color:"white"
            }
        },
        series: [
            {
                color:["orange","pink"],
                name: '月最大负荷',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: {
                    borderRadius: 10,
                    borderColor: '#fff',
                    borderWidth: 2
                },
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: 40,
                        fontWeight: 'bold'
                    }
                },
                labelLine: {
                    show: false
                },
                data: [
                    { value: 82, name: '月最大负荷' },
                    { value: 18, name: '' },
                ]
            }
        ]
    };

    const option2 = {
        tooltip: {
            trigger: 'item'
        },
        legend: {
            top: '2%',
            left: 'center',
            textStyle:{
                color:"white"
            }
        },
        series: [
            {
                name: '年最大负荷',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
                itemStyle: {
                    borderRadius: 10,
                    borderColor: '#fff',
                    borderWidth: 2
                },
                label: {
                    show: false,
                    position: 'center'
                },
                emphasis: {
                    label: {
                        show: true,
                        fontSize: 40,
                        fontWeight: 'bold'
                    }
                },
                labelLine: {
                    show: false
                },
                data: [
                    { value: 75, name: '年最大负荷' },
                    { value: 25, name: '' },
                ]
            }
        ]
    };

    return (
        <div style={{height:"100%"}}>
            <div >
                <ReactECharts option={option}  style={{width:"100%",height:"180px"}} />,
            </div>
            <div >
                <ReactECharts option={option2} style={{width:"100%",height:"180px"}} />,
            </div>
        </div>

    );
};

export default ChartComponent;
