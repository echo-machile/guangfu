import React from 'react';
import ReactECharts from 'echarts-for-react';

const ChartComponent = () => {
    const option = {
        color:"red",
        title: {
            text: '光伏发电站月发电总量',
            textStyle:{
                color: "white",
            }
        },
        tooltip: {
            trigger: 'axis'
        },
        xAxis: {
            type: 'category',
            data:  ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月','十二月']
        },
        yAxis: {
            type: 'value',
            label:"单位万KW/h",
            axisLabel: {
                formatter: '{value} 万KW/h',
            },
        },
        series: [
            {
                data: [102.8345,
                    66.6636,
                    164.8355,
                    181.6583,
                    163.6374,
                    139.389,
                    130.4353,
                    137.6665,
                    140.5643,
                    165.0116,
                    114.2916,
                    142.1196],
                type: 'bar',
                showBackground: true,
                backgroundStyle: {
                    color: 'rgba(180, 180, 180, 0.2)'
                }
            }
        ]
    };

    return (
        <ReactECharts option={option} style={{ width: '100%', height: '100%',backgroundColor: "rgba(1, 0.3, 0.2, 0.6)" }}  />
    );
};

export default ChartComponent;
