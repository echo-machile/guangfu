import React from 'react';
import ReactECharts from 'echarts-for-react';

const ChartComponent = () => {
    const option = {
        color:"blue",
        title: {
            text: '月弃光率',
            textStyle:{
                color: "white",
            }
        },
        tooltip: {
            trigger: 'axis'
        },
        xAxis: {
            type: 'category',
            data:  ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '八月', '九月', '十月', '十一月','十二月'],
            axisLabel: {
                show: true,
                color: '#333', // 标签文字的颜色
                fontSize: 12, // 标签文字的字体大小
                rotate: 0 // 标签文字的旋转角度
            }
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                formatter: '{value}%',
            },
        },
        series: [
            {
                data: [1.80,
                3.20,
                2.21,
                2.56,
                1.72,
                1.25,
                1.32,
                1.55,
                2.20,
                2.52,
                1.92,
                1.80],
                type: 'bar',
                showBackground: true,
                backgroundStyle: {
                    color: 'rgba(180, 180, 180, 0.2)'
                }
            }
        ]
    };

    return (
        <ReactECharts option={option} style={{ width: '100%', height: '100%',backgroundColor: "rgba(1, 0.3, 0.2, 0.6)" }}  />
    );
};

export default ChartComponent;
