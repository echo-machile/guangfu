import React from 'react';
import YearElect from "./YearElect";
import MonthElect from "./MonthElect";
import DaysElect from "./DaysElect";
import MonthRate from "./MonthRate";

const Page5 = () => {
    return (
        <div style={{ display: 'flex', flexDirection: 'column', height: '100vh', justifyContent: 'space-between' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', flex: 1 }}>
                <div style={{ width: '50%' }}>
                    <YearElect />
                </div>
                <div style={{ width: '50%' }}>
                    <MonthElect />
                </div>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', flex: 1 }}>
                <div style={{ width: '50%' }}>
                    <DaysElect />
                </div>
                <div style={{ width: '50%' }}>
                    <MonthRate></MonthRate>
                </div>
            </div>
        </div>
    );
};

export default Page5;
