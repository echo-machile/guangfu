import React from 'react';
import { useParams } from 'react-router-dom';
import { ECharts } from 'echarts';
import ReactECharts from 'echarts-for-react';
import { fakeData } from '../data/fateData';

const EchartsPage = (props) => {
    const { id } = props;
    const data = fakeData[id - 1];

    const getOption = () => {
        return {
            title: {
                text: data?.title,
            },
            xAxis: {
                type: 'category',
                data: data?.xAxis,
            },
            yAxis: {
                type: 'value',
            },
            series: [
                {
                    data: data?.yAxis,
                    type: 'line',
                },
            ],
        };
    };

    return (
        <div>
            <ReactECharts option={getOption()} style={{ height: '400px', width: '100%' }} />
        </div>
    );
};

export default EchartsPage;
