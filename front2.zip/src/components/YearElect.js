import React from 'react';
import ReactECharts from 'echarts-for-react';

const ChartComponent = () => {
    const option = {
        color:"green",
        title: {
            text: '光伏发电站年发电总量',
            textStyle:{
                color: "white",

            }
        },
        tooltip: {
            trigger: 'axis'
        },
        xAxis: {
            type: 'category',
            data: ['2014', '2015', '2016', '2017', '2018', '2019', '2020','2021','2022']
        },
        yAxis: {
            type: 'value',
            axisLabel: {
                formatter: '{value}万KW/h',
            },
        },
        series: [
            {
                data: [1230.3912,
                    1457.2387,
                    1477.7654,
                    1504.2315,
                    1512.7407,
                    1639.9134,
                    1620.7814,
                    1625.4373,
                    1649.5609],
                type: 'bar',
                showBackground: true,
                backgroundStyle: {
                    color: 'rgba(180, 180, 180, 0.2)'
                }
            }
        ]
    };

    return (
        <ReactECharts option={option} style={{ width: '100%', height: '100%',backgroundColor: "rgba(1, 0.3, 0.2, 0.6)" }}  />
    );
};

export default ChartComponent;
