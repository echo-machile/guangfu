import React from 'react';
import ReactECharts from 'echarts-for-react';

const EChartsComponent = () => {
    const option = {
        title: {
            text: '温度',
            textStyle:{
                color: 'white',
            }

        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: [ '温度'],
            textStyle: {
                color: 'white'
            }
        },

        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            axisLabel: {
                color: 'white' // 设置横坐标标签颜色为红色
            },
            data: [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]
        },
        yAxis: {
            type: 'value',
            color: 'white',
            axisLabel: {
                color: 'white' // 设置横坐标标签颜色为红色
            },
        },
        series: [
            {
                name: '温度',
                type: 'line',
                data: [4,4,4,5,6,6,7,9,11,12,15,16,16,18,19,17,15,15,12,9,4,4,2,-1]
            }
        ]
    };

    return (
        <ReactECharts option={option} style={{ width: '100%', height: '100%',backgroundColor: "rgba(1, 0.3, 0.2, 0.6)" }}  />
    );
};

export default EChartsComponent;
