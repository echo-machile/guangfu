import React from 'react';
import ReactECharts from 'echarts-for-react';

const EChartsComponent = () => {
    const option = {
        title: {
            text: '月发电总量'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['实际发电总量', '预测发电总量']
        },
        grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            containLabel: true
        },
        toolbox: {
            feature: {
                saveAsImage: {}
            }
        },
        xAxis: {
            type: 'category',
            boundaryGap: false,
            data: ['一月', '二月', '三月', '四月', '五月', '六月', '七月', '七月', '八月', '九月', '十月', '十一月','十二月']
        },
        yAxis: {
            type: 'value'
        },
        series: [
            {
                name: '实际发电总量',
                type: 'line',
                stack: 'Total',
                data: [
                    102.8345,
                    66.6636,
                    164.8355,
                    181.6583,
                    163.6374,
                    139.389,
                    130.4353,
                    137.6665,
                    140.5643,
                    165.0116,
                    114.2916,
                    142.1196]
            },
            {
                name: '预测发电总量',
                type: 'line',
                stack: 'Total',
                data: [
                    100.2315,
                    68.5526,
                    164.0514,
                    178.2156,
                    165.3759,
                    144.2756,
                    131.4433,
                    140.9051,
                    140.8721,
                    170.7579,
                    116.3754,
                    140.2576]
            }
        ]
    };

    return (
        <ReactECharts option={option} style={{ width: '100%', height: '100%',backgroundColor: "rgba(1, 0.3, 0.2, 0.6)" }}  />
    );
};

export default EChartsComponent;
