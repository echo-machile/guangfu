import React from 'react';
import ReactECharts from 'echarts-for-react';
import { Card } from 'antd';

const Page4 = () => {
    const curveChartOption = {
        title: {
            text: '山西省日负荷曲线'
        },
        tooltip: {
            trigger: 'axis'
        },
        xAxis: {
            type: 'category',
            data: [1,
                2,
                3,
                4,
                5,
                6,
                7,
                8,
                9,
                10,
                11,
                12,
                13,
                14,
                15,
                16,
                17,
                18,
                19,
                20,
                21,
                22,
                23,
                24]
        },
        yAxis: {
            type: 'value'
        },
        series: [
            {
                data: [2449,
                    2321,
                    2273,
                    2257,
                    2226,
                    2241,
                    2209,
                    2274,
                    2449,
                    2577,
                    2641,
                    2669,
                    2705,
                    2648,
                    2668,
                    2637,
                    2643,
                    2568,
                    2571,
                    2651,
                    2717,
                    2668,
                    2512,
                    2442],
                type: 'line',
                smooth: true
            }
        ]
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'space-around', alignItems: 'center', height: '100vh' }}>
            <div style={{ width: '48%', height: '60%' }}>
                <ReactECharts option={curveChartOption} style={{ width: '100%', height: '100%' }} />
            </div>
            <div style={{ width: '48%', height: '60%' }}>
                <Card
                    title="信息框"
                    bordered
                    style={{
                        width: '100%',
                        height: '100%',
                        borderRadius: '1rem',
                        backgroundColor: 'rgba(1, 0.3, 0.2, 0.6)',
                        color: 'white',
                        fontSize: '1.5rem',
                        fontWeight: 'bold'
                    }}
                    headStyle={{ color: 'white', fontWeight: 'bold', fontSize: '1.5rem' }}
                    bodyStyle={{ color: 'white', fontWeight: 'bold', fontSize: '1.5rem' }}

                >
                    <p>故障光伏板预测</p>
                    <p>001路-光伏板010</p>
                </Card>
            </div>
        </div>
    );
};

export default Page4;
