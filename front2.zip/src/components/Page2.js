import React, { useState } from 'react';
import { Map } from '@uiw/react-amap';
import { Table, Select } from 'antd';
import { EnvironmentOutlined } from '@ant-design/icons';
import EChartsComponent from "./EChartsComponent";
import EChartsComponent2 from "./EChartsComponent2";
import {Paper} from "@mui/material";

const { Option } = Select;

const Page2 = () => {
    const [selectedValue, setSelectedValue] = useState('option1');

    const handleChange = (value) => {
        setSelectedValue(value);
    };

    // 用于表格的假数据
    const fakeData = [
        {
            key: '1',
            panelId: '001',
            status: '正常',
            temperature: '17.4℃',
            lightIntensity: '12796 W/m²',
        },{
            key: '2',
            panelId: '002',
            status: '正常',
            temperature: '17.8℃',
            lightIntensity: '12796 W/m²',
        },{
            key: '3',
            panelId: '004',
            status: '正常',
            temperature: '17.6℃',
            lightIntensity: '12796 W/m²',
        },{
            key: '4',
            panelId: '004',
            status: '正常',
            temperature: '17.9℃',
            lightIntensity: '12796 W/m²',
        }
    ];

    const columns = [
        {
            title: '光电板序号',
            dataIndex: 'panelId',
        },
        {
            title: '当前状态',
            dataIndex: 'status',
        },
        {
            title: '温度',
            dataIndex: 'temperature',
        },
        {
            title: '光照强度',
            dataIndex: 'lightIntensity',
        },
    ];

    const getEChartsOption = () => ({
        // 配置图表选项...
    });

    return (
        <div style={{ width: "100%",height: "100vh", display: "flex", flexDirection: "row" }}>
                <div style={{ width:"50%",paddingTop:"1rem" }}>
                    <Map
                        amapkey="fdbb958972ec67d268114b4866ee7349"
                        version="1.4.15"
                        plugins={['ToolBar']}
                        zoom={11}
                        style={{ width: "100%", height: "50%" }}
                    />
                    <Table
                        dataSource={fakeData}
                        columns={columns}
                        pagination={false}
                        style={{ width: "100%", height: "50%", marginTop: "1rem" }}
                        title={() => (
                            <div align={"right"}>
                                <Select
                                    value={selectedValue}
                                    onChange={handleChange}
                                    style={{ marginLeft: 10 }}
                                >
                                    <Option value="option1">选项1</Option>
                                    <Option value="option2">选项2</Option>
                                </Select>
                            </div>
                        )}
                    />
                </div>
                <div style={{ width: "50%", height: "100%", padding: "1rem"  }}>
                    <Paper style={{height:"47%",borderRadius:"2rem",margin:"0 1rem",paddingTop:"1rem",backgroundColor: "rgba(1, 0.3, 0.2, 0.6)",color: "white"}} >
                        <h2>
                            <EnvironmentOutlined /> 光伏电站环境实时监控
                        </h2>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <div style={{width:"33%",fontSize: "1.5rem"}}>
                                <p >温度 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem"}}>35℃ </p>
                            </div>
                            <div style={{width:"33%",fontSize: "1.5rem"}}>
                                <p >光照强度 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem"}}>200 W/m² </p>
                            </div>
                            <div style={{width:"33%",fontSize: "1.5rem"}}>
                                <p>气压 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem"}}>1013 hPa </p>
                            </div>
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                            <div style={{width:"33%",fontSize: "1.5rem"}}>
                                <p >云量 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem"}}>10%</p>
                            </div>
                            <div style={{width:"33%",fontSize: "1.5rem"}}>
                                <p >紫外线指数 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem",margin:"0"}}>60% </p>
                            </div>
                            <div style={{width:"33%",fontSize: "1.5rem"}}>
                                <p >PM2.5 </p>
                                <p style={{fontWeight:"bold",fontSize: "1.6rem"}}>45 ug/cm³</p>
                            </div>
                        </div>
                    </Paper>
                    <div>&nbsp;</div>
                    <div style={{ width:"100%",height: "300px",display: 'flex',marginLeft:"1rem",justifyContent: 'space-between' }}>
                        <EChartsComponent  style={{ width: "50%", height: "80%" }}/>
                        <EChartsComponent2  style={{ width: "50%", height: "80%" }}/>
                    </div>
                </div>
            </div>
);
};

export default Page2;
