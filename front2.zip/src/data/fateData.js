export const fakeData = [
    {
        xAxis: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        yAxis: [120, 200, 150, 80, 70, 110, 130],
        title: 'Page 1 Data',
    },
    {
        xAxis: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        yAxis: [50, 100, 80, 120, 180, 70, 110],
        title: 'Page 2 Data',
    },
    {
        xAxis: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        yAxis: [100, 150, 90, 130, 60, 180, 50],
        title: 'Page 3 Data',
    },
    {
        xAxis: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        yAxis: [200, 120, 180, 60, 90, 50, 140],
        title: 'Page 4 Data',
    },
    {
        xAxis: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
        yAxis: [170, 100, 140, 80, 110, 60, 190],
        title: 'Page 5 Data',
    },
];
